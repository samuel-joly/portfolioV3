# Bloc-Note
TXT file Explorer

Can do:
- Create file.txt
- Delete file.txt
- Modify and save
- Navigate in folder the easy way

WARNING: Creating a file with the same name of one other file cheked by BlocNote will cause rewriting the other file
